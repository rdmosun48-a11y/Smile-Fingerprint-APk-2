# OnePlus Batman FP Anim — OnePlus Nord CE 4 (Android 15 & 16) Build & Install Guide

## Configuration Summary
- **Package ID:** `com.oneplus.fp.emoji.anim`
- **Target / Compile SDK:** Android 16 (API Level 36) — backwards-compatible with Android 15 (API 35)
- **Min SDK:** Android 12 (API Level 31)
- **Target Overlay Package:** `com.android.systemui` (`com.oplus.fod.animation`)
- **Features:** Custom `BatmanFodView` (Bat-Signal, Batarang, Sonar Pulse, Shadow Smoke) + 30 PNG overlay frames (`360x360px` in `drawable-nodpi`) + `BiometricPrompt` test

## Option A: Zero-Install Cloud APK Build (GitHub Actions)
1. Save/push this repository to GitHub (`rdmosun48-a11y/Smile-Fingerprint-APk-2`).
2. Open the **Actions** tab and run **Build OnePlus Fingerprint APK**.
3. Download the compiled `OnePlus-Fingerprint-APK` artifact (`app-debug.apk` / `app-release.apk`) to your OnePlus Nord CE 4.

## Option B: Build Locally (Android Studio or CLI)
1. Unzip this archive and open the folder in **Android Studio** with Android SDK 35/36 and JDK 17 installed.
2. Run:
   ```bash
   gradle assembleDebug assembleRelease
   ```
3. Install on OnePlus Nord CE 4:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## Activate System Lock Screen FOD Overlay (OnePlus OxygenOS 15 / 16)
Android 15 & 16 enforce RRO signature & privilege checks on `com.android.systemui`:
- **Root (Magisk / KernelSU / APatch):** Place the overlay APK inside a Magisk module at `/system/product/overlay/`.
- **ADB / Shizuku (compatible OxygenOS builds):**
  ```bash
  adb shell cmd overlay enable --user 0 com.oneplus.fp.emoji.anim
  adb shell cmd overlay set-priority com.oneplus.fp.emoji.anim highest
  ```
