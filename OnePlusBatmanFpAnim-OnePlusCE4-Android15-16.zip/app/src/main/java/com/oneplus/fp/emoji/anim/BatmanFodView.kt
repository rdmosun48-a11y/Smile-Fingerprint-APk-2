package com.oneplus.fp.emoji.anim

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class BatmanFodView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Skill(val label: String, val activeStatus: String) {
        BAT_SIGNAL("Bat-Signal", "Projecting Gotham Bat-Signal..."),
        BATARANG("Batarang", "Spinning kinetic Batarang array..."),
        SONAR("Sonar Pulse", "Scanning WayneTech sonar grid..."),
        SMOKE("Shadow Smoke", "Deploying tactical smoke veil...")
    }

    private data class PulseRing(
        var x: Float,
        var y: Float,
        var radius: Float,
        val maxRadius: Float,
        val alpha: Float,
        val speed: Float,
        val lineWidth: Float
    )

    private data class Particle(
        var x: Float,
        var y: Float,
        val vx: Float,
        val vy: Float,
        val size: Float,
        val alpha: Float,
        var life: Float,
        val maxLife: Float,
        var rotation: Float,
        val vRot: Float
    )

    var onStatusChange: ((String) -> Unit)? = null

    private var currentSkill: Skill = Skill.BAT_SIGNAL
    private var isHolding = false
    private var cycleEndMs = 0L
    private var lastFrameMs = 0L
    private var startMs = 0L
    private var lastEmitMs = 0L
    private var energy = 0f

    private val rings = mutableListOf<PulseRing>()
    private val particles = mutableListOf<Particle>()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val clipPath = Path()
    private val batarangPath = Path()
    private val dstRect = RectF()

    private val batBitmap: Bitmap? = createTransparentBatBitmap()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            invalidate()
        }
    }

    private fun createTransparentBatBitmap(): Bitmap? {
        val raw = BitmapFactory.decodeResource(resources, R.drawable.bat_emblem) ?: return null
        val w = raw.width
        val h = raw.height
        val pixels = IntArray(w * h)
        raw.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val lum = Color.red(pixels[i])
            pixels[i] = if (lum > 20) Color.argb(lum, 255, 255, 255) else Color.TRANSPARENT
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        if (raw != out) raw.recycle()
        return out
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startMs = System.currentTimeMillis()
        lastFrameMs = startMs
        if (!animator.isStarted) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    fun setSkill(skill: Skill) {
        currentSkill = skill
        rings.clear()
        particles.clear()
        triggerCycle()
    }

    fun getSkill(): Skill = currentSkill

    fun triggerCycle(touchX: Float = width / 2f, touchY: Float = height / 2f) {
        val now = System.currentTimeMillis()
        cycleEndMs = now + 2800L
        lastEmitMs = now
        val cx = if (touchX > 0f) touchX else max(width, 1) / 2f
        val cy = if (touchY > 0f) touchY else max(height, 1) / 2f
        spawnRing(cx, cy, intense = true)
        spawnParticles(cx, cy, if (currentSkill == Skill.BAT_SIGNAL) 8 else 6)
        onStatusChange?.invoke(currentSkill.activeStatus)
    }

    private fun spawnRing(x: Float, y: Float, intense: Boolean) {
        val maxR = min(width, height) * 0.48f
        rings.add(
            PulseRing(
                x = x,
                y = y,
                radius = if (intense) maxR * 0.08f else maxR * 0.14f,
                maxRadius = maxR,
                alpha = if (intense) 0.95f else 0.6f,
                speed = if (intense) maxR * 1.15f else maxR * 0.85f,
                lineWidth = if (intense) 6f else 4f
            )
        )
        if (rings.size > 14) rings.removeAt(0)
    }

    private fun spawnParticles(x: Float, y: Float, count: Int) {
        val w = max(width, 1).toFloat()
        val h = max(height, 1).toFloat()
        repeat(count) {
            val angle = Random.nextFloat() * (2f * PI.toFloat())
            when (currentSkill) {
                Skill.BAT_SIGNAL -> {
                    particles.add(
                        Particle(
                            x = Random.nextFloat() * w,
                            y = -15f - Random.nextFloat() * 35f,
                            vx = -w * 0.12f,
                            vy = h * (0.95f + Random.nextFloat() * 0.4f),
                            size = h * (0.04f + Random.nextFloat() * 0.04f),
                            alpha = 0.4f + Random.nextFloat() * 0.4f,
                            life = 0f,
                            maxLife = 1.1f,
                            rotation = 0f,
                            vRot = 0f
                        )
                    )
                }
                Skill.BATARANG -> {
                    val spd = w * (0.36f + Random.nextFloat() * 0.42f)
                    particles.add(
                        Particle(
                            x = x,
                            y = y,
                            vx = cos(angle) * spd,
                            vy = sin(angle) * spd,
                            size = w * (0.025f + Random.nextFloat() * 0.025f),
                            alpha = 0.95f,
                            life = 0f,
                            maxLife = 0.75f + Random.nextFloat() * 0.35f,
                            rotation = Random.nextFloat() * (2f * PI.toFloat()),
                            vRot = (if (Random.nextBoolean()) 1f else -1f) * (9f + Random.nextFloat() * 7f)
                        )
                    )
                }
                Skill.SONAR -> {
                    val spd = w * (0.22f + Random.nextFloat() * 0.25f)
                    particles.add(
                        Particle(
                            x = x,
                            y = y,
                            vx = cos(angle) * spd,
                            vy = sin(angle) * spd,
                            size = w * (0.008f + Random.nextFloat() * 0.008f),
                            alpha = 0.9f,
                            life = 0f,
                            maxLife = 1.0f,
                            rotation = 0f,
                            vRot = 0f
                        )
                    )
                }
                Skill.SMOKE -> {
                    val spd = w * (0.08f + Random.nextFloat() * 0.15f)
                    particles.add(
                        Particle(
                            x = x + (Random.nextFloat() - 0.5f) * (w * 0.1f),
                            y = y + (Random.nextFloat() - 0.5f) * (w * 0.1f),
                            vx = cos(angle) * spd,
                            vy = sin(angle) * spd - w * 0.05f,
                            size = w * (0.05f + Random.nextFloat() * 0.07f),
                            alpha = 0.4f + Random.nextFloat() * 0.25f,
                            life = 0f,
                            maxLife = 1.3f + Random.nextFloat() * 0.5f,
                            rotation = 0f,
                            vRot = 0f
                        )
                    )
                }
            }
        }
        if (particles.size > 48) {
            particles.subList(0, particles.size - 48).clear()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                isHolding = true
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                triggerCycle(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val now = System.currentTimeMillis()
                if (isHolding && now - lastEmitMs > 140L) {
                    lastEmitMs = now
                    spawnRing(event.x, event.y, intense = false)
                    spawnParticles(event.x, event.y, 2)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isHolding = false
                cycleEndMs = 0L
                onStatusChange?.invoke("Hold sensor to activate Batman skill")
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.currentTimeMillis()
        if (startMs == 0L) startMs = now
        if (lastFrameMs == 0L) lastFrameMs = now
        val dt = ((now - lastFrameMs) / 1000f).coerceIn(0.001f, 0.05f)
        lastFrameMs = now
        val t = (now - startMs) / 1000f

        val isActive = isHolding || now < cycleEndMs
        val targetEnergy = if (isActive) 1f else 0f
        val rate = if (isActive) 8f else 3.2f
        energy += (targetEnergy - energy) * min(1f, dt * rate)

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val basinRadius = min(w, h) * 0.45f

        if (isActive && now - lastEmitMs > (if (currentSkill == Skill.BAT_SIGNAL) 95L else 220L)) {
            lastEmitMs = now
            if (currentSkill == Skill.BAT_SIGNAL) {
                spawnParticles(cx, cy, 3)
            } else {
                spawnRing(cx, cy, intense = true)
                spawnParticles(cx, cy, 5)
            }
        }

        clipPath.reset()
        clipPath.addCircle(cx, cy, basinRadius, Path.Direction.CW)

        canvas.save()
        canvas.clipPath(clipPath)
        canvas.drawColor(Color.BLACK)

        when (currentSkill) {
            Skill.BAT_SIGNAL -> drawBatSignalBg(canvas, cx, cy, w, h, basinRadius, t)
            Skill.BATARANG -> drawBatarangBg(canvas, cx, cy, basinRadius, t)
            Skill.SONAR -> drawSonarBg(canvas, cx, cy, basinRadius, t)
            Skill.SMOKE -> drawSmokeBg(canvas, cx, cy, basinRadius, t)
        }

        drawParticles(canvas, dt)
        drawBatEmblem(canvas, cx, cy, basinRadius, t)
        drawRings(canvas, dt)

        canvas.restore()

        val bezelColor = when (currentSkill) {
            Skill.BAT_SIGNAL -> Color.argb(((0.26f + energy * 0.65f) * 255).toInt(), 245, 158, 11)
            Skill.BATARANG -> Color.argb(((0.26f + energy * 0.65f) * 255).toInt(), 235, 0, 40)
            Skill.SONAR -> Color.argb(((0.26f + energy * 0.65f) * 255).toInt(), 56, 189, 248)
            Skill.SMOKE -> Color.argb(((0.26f + energy * 0.65f) * 255).toInt(), 148, 163, 184)
        }
        strokePaint.shader = null
        strokePaint.color = bezelColor
        strokePaint.strokeWidth = 3f + energy * 3f
        canvas.drawCircle(cx, cy, basinRadius, strokePaint)
    }

    private fun drawBatSignalBg(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        w: Float,
        h: Float,
        basinRadius: Float,
        t: Float
    ) {
        val sway = sin(t * 2.1f) * (0.12f + energy * 0.24f)
        fillPaint.shader = RadialGradient(
            cx + sin(sway) * (w * 0.08f),
            cy + cos(sway) * (h * 0.03f),
            basinRadius,
            intArrayOf(
                Color.argb(((0.22f + energy * 0.52f) * 255).toInt(), 251, 191, 36),
                Color.argb(((0.09f + energy * 0.24f) * 255).toInt(), 245, 158, 11),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, basinRadius, fillPaint)
        fillPaint.shader = null

        fillPaint.color = Color.argb(((0.08f + energy * 0.24f) * 255).toInt(), 254, 240, 138)
        canvas.drawCircle(cx, cy, basinRadius * 0.60f + energy * 14f * sin(t * 4f), fillPaint)
    }

    private fun drawBatarangBg(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        basinRadius: Float,
        t: Float
    ) {
        fillPaint.shader = RadialGradient(
            cx,
            cy,
            basinRadius,
            intArrayOf(
                Color.argb(((0.10f + energy * 0.34f) * 255).toInt(), 235, 0, 40),
                Color.argb(((0.04f + energy * 0.14f) * 255).toInt(), 127, 29, 29),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, basinRadius, fillPaint)
        fillPaint.shader = null

        val orbitR = basinRadius * 0.69f + sin(t * 5f) * (6f * energy)
        val baseRot = t * (1.2f + energy * 5.2f)
        for (i in 0 until 3) {
            val a = baseRot + i * (2f * PI.toFloat() / 3f)
            val bx = cx + cos(a) * orbitR
            val by = cy + sin(a) * orbitR
            drawMiniBatarang(
                canvas,
                bx,
                by,
                basinRadius * (0.085f + energy * 0.03f),
                Math.toDegrees((a + t * 10f).toDouble()).toFloat(),
                ((0.35f + energy * 0.65f) * 255).toInt(),
                Color.WHITE
            )
        }
    }

    private fun drawSonarBg(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        basinRadius: Float,
        t: Float
    ) {
        fillPaint.shader = RadialGradient(
            cx,
            cy,
            basinRadius,
            intArrayOf(
                Color.argb(((0.14f + energy * 0.30f) * 255).toInt(), 56, 189, 248),
                Color.argb(((0.06f + energy * 0.16f) * 255).toInt(), 14, 116, 144),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, basinRadius, fillPaint)
        fillPaint.shader = null

        strokePaint.shader = null
        strokePaint.color = Color.argb(((0.14f + energy * 0.22f) * 255).toInt(), 56, 189, 248)
        strokePaint.strokeWidth = 2f
        for (frac in floatArrayOf(0.35f, 0.60f, 0.85f)) {
            canvas.drawCircle(cx, cy, basinRadius * frac, strokePaint)
        }
        canvas.drawLine(cx - basinRadius, cy, cx + basinRadius, cy, strokePaint)
        canvas.drawLine(cx, cy - basinRadius, cx, cy + basinRadius, strokePaint)

        val sweepDeg = Math.toDegrees((t * (1.8f + energy * 3.8f)).toDouble()).toFloat()
        canvas.save()
        canvas.rotate(sweepDeg, cx, cy)
        fillPaint.shader = LinearGradient(
            cx,
            cy,
            cx + basinRadius,
            cy,
            Color.argb(((0.15f + energy * 0.45f) * 255).toInt(), 56, 189, 248),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        dstRect.set(cx - basinRadius, cy - basinRadius, cx + basinRadius, cy + basinRadius)
        canvas.drawArc(dstRect, -26f, 26f, true, fillPaint)
        fillPaint.shader = null
        canvas.restore()
    }

    private fun drawSmokeBg(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        basinRadius: Float,
        t: Float
    ) {
        fillPaint.shader = RadialGradient(
            cx,
            cy,
            basinRadius,
            intArrayOf(
                Color.argb(((0.12f + energy * 0.25f) * 255).toInt(), 148, 163, 184),
                Color.argb(((0.10f + energy * 0.24f) * 255).toInt(), 51, 65, 85),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, basinRadius, fillPaint)
        fillPaint.shader = null

        val rotDeg = Math.toDegrees((t * (0.4f + energy * 1.1f)).toDouble()).toFloat()
        val bracketR = basinRadius * 0.70f - energy * 14f
        strokePaint.shader = null
        strokePaint.color = Color.argb(((0.22f + energy * 0.55f) * 255).toInt(), 226, 232, 240)
        strokePaint.strokeWidth = 3.5f
        dstRect.set(cx - bracketR, cy - bracketR, cx + bracketR, cy + bracketR)
        for (q in 0 until 4) {
            canvas.drawArc(dstRect, rotDeg + q * 90f - 20f, 40f, false, strokePaint)
        }
    }

    private fun drawMiniBatarang(
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float,
        deg: Float,
        alpha: Int,
        color: Int
    ) {
        canvas.save()
        canvas.translate(x, y)
        canvas.rotate(deg)
        batarangPath.reset()
        batarangPath.moveTo(0f, -size * 0.28f)
        batarangPath.lineTo(size * 0.18f, -size * 0.45f)
        batarangPath.lineTo(size * 0.22f, -size * 0.12f)
        batarangPath.quadTo(size * 0.72f, -size * 0.26f, size, -size * 0.05f)
        batarangPath.quadTo(size * 0.58f, size * 0.35f, 0f, size * 0.52f)
        batarangPath.quadTo(-size * 0.58f, size * 0.35f, -size, -size * 0.05f)
        batarangPath.quadTo(-size * 0.72f, -size * 0.26f, -size * 0.22f, -size * 0.12f)
        batarangPath.lineTo(-size * 0.18f, -size * 0.45f)
        batarangPath.close()
        fillPaint.shader = null
        fillPaint.color = Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawPath(batarangPath, fillPaint)
        canvas.restore()
    }

    private fun drawParticles(canvas: Canvas, dt: Float) {
        val iter = particles.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            p.life += dt
            if (p.life >= p.maxLife) {
                iter.remove()
                continue
            }
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rotation += p.vRot * dt
            val progress = p.life / p.maxLife
            val fade = sin(progress * PI.toFloat())

            when (currentSkill) {
                Skill.BAT_SIGNAL -> {
                    strokePaint.shader = null
                    strokePaint.color = Color.argb(
                        ((p.alpha * fade * (0.35f + energy * 0.65f)) * 255).toInt().coerceIn(0, 255),
                        253, 230, 138
                    )
                    strokePaint.strokeWidth = 2.4f
                    canvas.drawLine(p.x, p.y, p.x + p.vx * 0.04f, p.y + p.size, strokePaint)
                }
                Skill.BATARANG -> {
                    drawMiniBatarang(
                        canvas,
                        p.x,
                        p.y,
                        p.size,
                        Math.toDegrees(p.rotation.toDouble()).toFloat(),
                        ((p.alpha * (1f - progress)) * 255).toInt(),
                        Color.rgb(252, 165, 165)
                    )
                }
                Skill.SONAR -> {
                    fillPaint.shader = null
                    fillPaint.color = Color.argb(
                        ((p.alpha * (1f - progress)) * 255).toInt().coerceIn(0, 255),
                        125, 211, 252
                    )
                    canvas.drawCircle(p.x, p.y, p.size, fillPaint)
                }
                Skill.SMOKE -> {
                    val pr = p.size * (0.8f + progress * 1.4f)
                    fillPaint.shader = RadialGradient(
                        p.x, p.y, pr,
                        Color.argb(((p.alpha * fade) * 255).toInt().coerceIn(0, 255), 148, 163, 184),
                        Color.TRANSPARENT,
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawCircle(p.x, p.y, pr, fillPaint)
                    fillPaint.shader = null
                }
            }
        }
    }

    private fun drawBatEmblem(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        basinRadius: Float,
        t: Float
    ) {
        val bmp = batBitmap ?: return
        val pulse = if (currentSkill == Skill.BATARANG) {
            1f + energy * 0.09f * abs(sin(t * 7f))
        } else {
            1f + energy * 0.07f * sin(t * 4.5f)
        }
        val size = basinRadius * 1.15f * pulse
        val half = size / 2f

        canvas.save()
        if (currentSkill == Skill.BATARANG && energy > 0.05f) {
            canvas.rotate(sin(t * 8f) * 2.5f * energy, cx, cy)
        }
        dstRect.set(cx - half, cy - half, cx + half, cy + half)
        canvas.drawBitmap(bmp, null, dstRect, iconPaint)
        canvas.restore()
    }

    private fun drawRings(canvas: Canvas, dt: Float) {
        val rgb = when (currentSkill) {
            Skill.BAT_SIGNAL -> Triple(251, 191, 36)
            Skill.BATARANG -> Triple(235, 0, 40)
            Skill.SONAR -> Triple(56, 189, 248)
            Skill.SMOKE -> Triple(203, 213, 225)
        }
        val iter = rings.iterator()
        while (iter.hasNext()) {
            val r = iter.next()
            r.radius += r.speed * dt
            val progress = r.radius / r.maxRadius
            val alpha = r.alpha * max(0f, 1f - progress)
            if (progress >= 1f || alpha <= 0.01f) {
                iter.remove()
                continue
            }
            strokePaint.shader = null
            strokePaint.color = Color.argb((alpha * 255).toInt().coerceIn(0, 255), rgb.first, rgb.second, rgb.third)
            strokePaint.strokeWidth = max(1.5f, r.lineWidth * (1f - progress * 0.45f))
            canvas.drawCircle(r.x, r.y, r.radius, strokePaint)
        }
    }
}
