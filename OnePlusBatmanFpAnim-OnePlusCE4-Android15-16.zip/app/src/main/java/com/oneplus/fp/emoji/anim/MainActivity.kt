package com.oneplus.fp.emoji.anim

import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

class MainActivity : AppCompatActivity() {

    private lateinit var fodView: BatmanFodView
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root_container)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(left = bars.left, top = bars.top, right = bars.right, bottom = bars.bottom)
            insets
        }

        fodView = findViewById(R.id.fod_animation_view)
        statusText = findViewById(R.id.status_label)
        val btnBiometric = findViewById<Button>(R.id.btn_test_biometric)
        val btnReplay = findViewById<Button>(R.id.btn_replay_anim)
        val specText = findViewById<TextView>(R.id.device_spec_label)

        val btnSignal = findViewById<Button>(R.id.btn_skill_batsignal)
        val btnBatarang = findViewById<Button>(R.id.btn_skill_batarang)
        val btnSonar = findViewById<Button>(R.id.btn_skill_sonar)
        val btnSmoke = findViewById<Button>(R.id.btn_skill_smoke)

        specText.text = "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · Target ${getString(R.string.target_pkg)}"

        fodView.onStatusChange = { msg ->
            statusText.text = msg
        }

        val skillButtons = mapOf(
            BatmanFodView.Skill.BAT_SIGNAL to btnSignal,
            BatmanFodView.Skill.BATARANG to btnBatarang,
            BatmanFodView.Skill.SONAR to btnSonar,
            BatmanFodView.Skill.SMOKE to btnSmoke
        )

        fun updateSkillHighlight(selected: BatmanFodView.Skill) {
            skillButtons.forEach { (skill, button) ->
                button.alpha = if (skill == selected) 1.0f else 0.55f
            }
        }

        skillButtons.forEach { (skill, button) ->
            button.setOnClickListener {
                fodView.setSkill(skill)
                updateSkillHighlight(skill)
            }
        }

        updateSkillHighlight(fodView.getSkill())

        btnReplay.setOnClickListener {
            fodView.triggerCycle()
        }

        btnBiometric.setOnClickListener {
            launchBiometricPrompt()
        }

        fodView.post {
            fodView.triggerCycle()
        }
    }

    private fun launchBiometricPrompt() {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "No hardware fingerprint enrolled on this device", Toast.LENGTH_SHORT).show()
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    fodView.triggerCycle()
                    statusText.text = "Biometric verified · ${fodView.getSkill().label} ready"
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    statusText.text = "Prompt cancelled: $errString"
                }
            }
        )

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("WayneTech FOD Verification")
            .setSubtitle("Verify ${fodView.getSkill().label} sensor response on Android ${Build.VERSION.RELEASE}")
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(authenticators)
            .build()

        prompt.authenticate(info)
    }
}
