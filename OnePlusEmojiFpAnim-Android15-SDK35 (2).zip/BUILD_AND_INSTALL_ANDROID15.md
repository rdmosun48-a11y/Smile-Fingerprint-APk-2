# OnePlus Emoji FP Anim — Android 15 (SDK 35) Build & Install Guide

## Configuration Summary
- **Package ID:** `com.oneplus.fp.emoji.anim`
- **Target SDK / Compile SDK:** Android 15 (API Level 35)
- **Min SDK:** Android 12 (API Level 31)
- **Target Overlay Package:** `com.android.systemui`
- **Frames:** 30 PNG frames (`360x360px` in `drawable-nodpi`) @ 60 FPS

---

## Option A: Build the APK Locally (Android Studio or CLI)
1. Unzip this archive and open the folder in **Android Studio Ladybug (2024.2.1)+** with Android SDK 35 installed.
2. Or build directly from terminal (with Gradle 8.9 & JDK 17):
   ```bash
   gradle assembleRelease
   ```
3. Output APK will be at:
   `app/build/outputs/apk/release/app-release.apk`

## Option B: Zero-Install Cloud APK Build (GitHub Actions)
1. Push this unzipped folder to a private or public GitHub repository.
2. Open the **Actions** tab and run **"Build Android 15 Fingerprint APK"**.
3. Download the compiled `oneplus-emoji-fp-android15-apk` artifact directly to your OnePlus phone.

---

## Installing & Activating on OnePlus (OxygenOS 15 / Android 15)

### 1. Sideload Standalone App
```bash
adb install -r app-release.apk
```
Open **OnePlus Emoji FP Anim** to verify the live animation and test your hardware sensor via Android 15 `BiometricPrompt`.

### 2. Activate System Lock Screen FOD Overlay (Root / Shizuku / ADB)
Android 15 enforces strict RRO signature & privilege checks on `com.android.systemui`:
- **Magisk / KernelSU / APatch**: Use the Magisk FOD Overlay Module ZIP exported from the studio so the overlay sits in `/system/product/overlay/` with proper SELinux context.
- **ADB / Shizuku Overlay Enable** (on compatible OxygenOS builds):
  ```bash
  adb shell cmd overlay enable --user 0 com.oneplus.fp.emoji.anim
  adb shell cmd overlay set-priority com.oneplus.fp.emoji.anim highest
  ```
